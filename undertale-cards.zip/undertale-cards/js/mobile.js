/* global Android */

var mobile;

function isMobileDevice() {
    return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
}

function mobileAppOnly() {
    if (mobile && typeof Android !== 'undefined') {
        $(".mobile-app-only").show();
    }
}

mobile = isMobileDevice();
mobileAppOnly();