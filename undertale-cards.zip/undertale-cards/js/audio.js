/* global Audio */

(function (window, document) {
    'use strict';

    if (window.UCAudio !== undefined) {
        return;
    }

    var AudioContextClass = window.AudioContext || window.webkitAudioContext;
    var silentAudioDataUri = 'data:audio/wav;base64,UklGRiYAAABXQVZFZm10IBAAAAABAAEAQB8AAIA+AAACABAAZGF0YQIAAAAAAA==';

    var audioContext = null;
    var audioContextUnlocked = false;
    var audioContextUnlocking = false;

    var audioBuffers = {};
    var audioBufferPromises = {};
    var activeEffects = [];
    var pendingEffect = null;

    var tracks = {};
    var listenersInstalled = false;

    var musicVolumeStorageKey = 'gameMusicVolume';
    var jingleVolumeStorageKey = 'gameJingleVolume';
    var effectsVolumeStorageKey = 'gameSoundsVolume';
    var defaultMasterVolume = 0.6;

    /*
     * iOS/iPadOS does not reliably apply HTMLMediaElement.volume.
     * Tracks started before the first user gesture therefore stay muted until
     * they can be routed through Web Audio and controlled with a GainNode.
     */
    var deferTrackOutputUntilAudioGraph =
        /iPad|iPhone|iPod/.test(navigator.userAgent)
        || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);

    function clampVolume(value) {
        var numericValue = Number(value);

        if (!isFinite(numericValue)) {
            return 1;
        }

        return Math.max(0, Math.min(1, numericValue));
    }

    /*
     * The slider remains linear from 0 to 100, but the applied gain uses a
     * quadratic curve so differences at medium and high volumes are clearer.
     */
    function volumeToGain(volume) {
        var normalizedVolume = clampVolume(volume);

        return normalizedVolume * normalizedVolume;
    }

    function readStoredVolume(storageKey) {
        try {
            var storedValue = localStorage.getItem(storageKey);

            if (storedValue === null) {
                return defaultMasterVolume;
            }

            return clampVolume(Number(storedValue) / 100);
        } catch (error) {
            return defaultMasterVolume;
        }
    }

    function persistVolume(storageKey, volume) {
        try {
            localStorage.setItem(
                storageKey,
                String(Math.round(clampVolume(volume) * 100))
            );
        } catch (error) {
            // Storage may be unavailable in private browsing modes.
        }
    }

    var musicVolume = readStoredVolume(musicVolumeStorageKey);
    var jingleVolume = readStoredVolume(jingleVolumeStorageKey);
    var effectsVolume = readStoredVolume(effectsVolumeStorageKey);

    function getAudioContext(createIfMissing) {
        if (audioContext !== null) {
            return audioContext;
        }

        if (!createIfMissing || !AudioContextClass) {
            return null;
        }

        try {
            /*
             * This is deliberately called from the first physical gesture.
             * Creating it from a WebSocket/AJAX callback is unreliable on mobile.
             */
            audioContext = new AudioContextClass();
        } catch (error) {
            console.warn('AudioContext initialization failed:', error && error.name);
            audioContext = null;
        }

        return audioContext;
    }

    function decodeAudioBuffer(context, arrayBuffer) {
        return new Promise(function (resolve, reject) {
            var settled = false;

            function resolveOnce(buffer) {
                if (!settled) {
                    settled = true;
                    resolve(buffer);
                }
            }

            function rejectOnce(error) {
                if (!settled) {
                    settled = true;
                    reject(error);
                }
            }

            try {
                var promise = context.decodeAudioData(
                    arrayBuffer.slice(0),
                    resolveOnce,
                    rejectOnce
                );

                if (promise && typeof promise.then === 'function') {
                    promise.then(resolveOnce).catch(rejectOnce);
                }
            } catch (error) {
                rejectOnce(error);
            }
        });
    }

    function loadEffectBuffer(source) {
        if (audioBuffers[source] !== undefined) {
            return Promise.resolve(audioBuffers[source]);
        }

        if (audioBufferPromises[source] !== undefined) {
            return audioBufferPromises[source];
        }

        var context = getAudioContext(false);

        if (context === null) {
            return Promise.reject(new Error('AudioContext is not unlocked'));
        }

        audioBufferPromises[source] = fetch(source, {
            credentials: 'same-origin'
        })
            .then(function (response) {
                if (!response.ok) {
                    throw new Error('Unable to load audio: ' + source);
                }

                return response.arrayBuffer();
            })
            .then(function (arrayBuffer) {
                return decodeAudioBuffer(context, arrayBuffer);
            })
            .then(function (buffer) {
                audioBuffers[source] = buffer;
                delete audioBufferPromises[source];
                return buffer;
            })
            .catch(function (error) {
                delete audioBufferPromises[source];
                throw error;
            });

        return audioBufferPromises[source];
    }

    function removeActiveEffect(source) {
        for (var i = 0; i < activeEffects.length; i++) {
            if (activeEffects[i].source === source) {
                activeEffects.splice(i, 1);
                return;
            }
        }
    }

    function playDecodedEffect(source, volume) {
        var context = getAudioContext(false);

        if (context === null
            || context.state !== 'running'
            || !audioContextUnlocked) {
            return;
        }

        loadEffectBuffer(source)
            .then(function (buffer) {
                if (context.state !== 'running' || !audioContextUnlocked) {
                    return;
                }

                var bufferSource = context.createBufferSource();
                var gain = context.createGain();
                var baseVolume = clampVolume(volume);

                bufferSource.buffer = buffer;
                gain.gain.value = baseVolume * volumeToGain(effectsVolume);

                bufferSource.connect(gain);
                gain.connect(context.destination);

                activeEffects.push({
                    source: bufferSource,
                    gain: gain,
                    baseVolume: baseVolume
                });

                bufferSource.onended = function () {
                    removeActiveEffect(bufferSource);

                    try {
                        bufferSource.disconnect();
                        gain.disconnect();
                    } catch (error) {
                        // It may already be disconnected.
                    }
                };

                bufferSource.start(0);
            })
            .catch(function (error) {
                console.warn('Effect playback failed:', source, error && error.message);
            });
    }

    function flushPendingEffect() {
        if (pendingEffect === null) {
            return;
        }

        var effect = pendingEffect;
        pendingEffect = null;

        /* Never replay an old page event much later. */
        if (Date.now() - effect.requestedAt > 1200) {
            return;
        }

        playDecodedEffect(effect.source, effect.volume);
    }

    function primeAudioContext(context) {
        try {
            var source = context.createBufferSource();
            source.buffer = context.createBuffer(1, 1, 22050);
            source.connect(context.destination);
            source.start(0);
        } catch (error) {
            // context.resume() remains the main unlock operation.
        }
    }

    function unlockAudioContext() {
        var context = getAudioContext(true);

        if (context === null || context.state === 'closed') {
            return;
        }

        /*
         * Only iOS tracks that were kept silent before the first interaction
         * are routed here. Desktop tracks already playing are left untouched,
         * avoiding the audible mini-freeze caused by hot rerouting.
         */
        ensureDeferredTracksAudioGraph(context);
        primeAudioContext(context);

        if (context.state === 'running') {
            audioContextUnlocked = true;
            audioContextUnlocking = false;
            flushPendingEffect();
            return;
        }

        if (audioContextUnlocking) {
            return;
        }

        audioContextUnlocking = true;

        var promise;

        try {
            promise = context.resume();
        } catch (error) {
            audioContextUnlocking = false;
            audioContextUnlocked = false;
            console.warn('AudioContext unlock failed:', error && error.name);
            return;
        }

        function finishUnlock() {
            audioContextUnlocking = false;
            audioContextUnlocked = context.state === 'running';

            if (audioContextUnlocked) {
                flushPendingEffect();
            }
        }

        if (promise && typeof promise.then === 'function') {
            promise
                .then(finishUnlock)
                .catch(function (error) {
                    audioContextUnlocking = false;
                    audioContextUnlocked = false;
                    console.warn('AudioContext unlock failed:', error && error.name);
                });
        } else {
            finishUnlock();
        }
    }

    function getTrackMasterVolume(track) {
        if (track.volumeGroup === 'jingle') {
            return volumeToGain(jingleVolume);
        }

        return volumeToGain(musicVolume);
    }

    function getTrackOutputVolume(track) {
        if (track.muted) {
            return 0;
        }

        return clampVolume(
            track.baseVolume * getTrackMasterVolume(track)
        );
    }

    function applyTrackOutputVolume(track) {
        var outputVolume = getTrackOutputVolume(track);

        if (track.audioGraphReady && track.gainNode !== null) {
            /*
             * Once routed through Web Audio, the GainNode is the only volume
             * control. Keep the HTMLAudio element itself at full volume.
             */
            track.element.volume = 1;
            track.element.muted = false;
            track.gainNode.gain.value = outputVolume;
            return;
        }

        if (track.deferredForAudioGraph) {
            /*
             * Prevent the first music frame from playing at system volume on
             * iOS before Web Audio has been unlocked.
             */
            track.element.volume = 1;
            track.element.muted = true;
            return;
        }

        /* Standard fallback for desktop/older browsers. */
        track.element.volume = outputVolume;
        track.element.muted = track.muted;
    }

    function ensureTrackAudioGraph(track, context) {
        if (track.audioGraphReady
            || track.audioGraphFailed
            || context === null
            || typeof context.createMediaElementSource !== 'function') {
            return;
        }

        try {
            /*
             * A HTMLMediaElement can only be attached to one
             * MediaElementAudioSourceNode, so these nodes are kept permanently.
             */
            track.mediaSourceNode = context.createMediaElementSource(track.element);
            track.gainNode = context.createGain();

            track.mediaSourceNode.connect(track.gainNode);
            track.gainNode.connect(context.destination);

            track.audioGraphReady = true;
            track.deferredForAudioGraph = false;

            applyTrackOutputVolume(track);
        } catch (error) {
            track.audioGraphFailed = true;
            track.deferredForAudioGraph = false;
            track.mediaSourceNode = null;
            track.gainNode = null;

            console.warn(
                'Track Web Audio routing failed:',
                error && error.name,
                error && error.message
            );

            applyTrackOutputVolume(track);
        }
    }

    function ensureDeferredTracksAudioGraph(context) {
        for (var name in tracks) {
            if (!Object.prototype.hasOwnProperty.call(tracks, name)) {
                continue;
            }

            var track = tracks[name];

            if (track.deferredForAudioGraph) {
                ensureTrackAudioGraph(track, context);
            }
        }
    }

    function createTrack(name) {
        if (tracks[name] !== undefined) {
            return tracks[name].element;
        }

        var element = new Audio();
        element.preload = 'auto';

        tracks[name] = {
            element: element,
            unlocked: false,
            priming: false,
            pending: null,
            baseVolume: 1,
            volumeGroup: 'music',
            muted: false,
            mediaSourceNode: null,
            gainNode: null,
            audioGraphReady: false,
            audioGraphFailed: false,
            deferredForAudioGraph: false
        };

        return element;
    }

    function getTrack(name) {
        if (tracks[name] === undefined) {
            createTrack(name);
        }

        return tracks[name];
    }

    function restorePrimedTrack(track, previous) {
        var element = track.element;

        /* Do not overwrite a real source assigned while priming was resolving. */
        if (element.getAttribute('src') !== silentAudioDataUri) {
            track.priming = false;
            return;
        }

        element.pause();

        if (previous.source) {
            element.src = previous.source;
            element.loop = previous.loop;
            element.load();
        } else {
            element.removeAttribute('src');
            element.load();
            element.loop = previous.loop;
        }

        track.priming = false;
        applyTrackOutputVolume(track);
    }

    function primeTrack(track) {
        if (track.unlocked || track.priming || track.pending !== null) {
            return;
        }

        track.priming = true;

        var element = track.element;
        var previous = {
            source: element.getAttribute('src') || '',
            volume: element.volume,
            loop: element.loop,
            muted: element.muted
        };

        element.src = silentAudioDataUri;
        element.volume = 0;
        element.loop = false;
        element.muted = false;

        var promise;

        try {
            promise = element.play();
        } catch (error) {
            restorePrimedTrack(track, previous);
            return;
        }

        if (promise === undefined) {
            track.unlocked = true;
            restorePrimedTrack(track, previous);
            return;
        }

        promise
            .then(function () {
                track.unlocked = true;
                restorePrimedTrack(track, previous);
            })
            .catch(function () {
                restorePrimedTrack(track, previous);
            });
    }

    function tryPlayTrack(track, queueUntilInteraction) {
        var element = track.element;
        var promise;

        try {
            promise = element.play();
        } catch (error) {
            if (queueUntilInteraction) {
                track.pending = {
                    source: element.getAttribute('src') || element.src
                };
            }

            console.warn('Track playback failed:', error && error.name);
            return;
        }

        if (promise === undefined) {
            track.unlocked = true;
            track.pending = null;
            return;
        }

        promise
            .then(function () {
                track.unlocked = true;
                track.pending = null;
            })
            .catch(function (error) {
                if (queueUntilInteraction && error && error.name === 'NotAllowedError') {
                    track.pending = {
                        source: element.getAttribute('src') || element.src
                    };
                }

                console.warn('Track playback failed:', error && error.name);
            });
    }

    function unlockTracks() {
        for (var name in tracks) {
            if (!Object.prototype.hasOwnProperty.call(tracks, name)) {
                continue;
            }

            var track = tracks[name];

            if (track.pending !== null) {
                tryPlayTrack(track, true);
            } else {
                primeTrack(track);
            }
        }
    }

    function unlock() {
        /*
         * This listener remains installed for the document lifetime. Mobile OSes
         * may suspend audio when the browser goes into the background.
         */
        unlockAudioContext();
        unlockTracks();
    }

    function installUnlockListeners() {
        if (listenersInstalled) {
            return;
        }

        listenersInstalled = true;

        /* Capture phase runs before page click handlers. */
        window.addEventListener('pointerdown', unlock, true);
        window.addEventListener('touchend', unlock, true);
        window.addEventListener('click', unlock, true);
        window.addEventListener('keydown', unlock, true);

        document.addEventListener('visibilitychange', function () {
            if (!document.hidden
                && audioContext !== null
                && audioContext.state !== 'running') {
                audioContextUnlocked = false;
            }
        });

        window.addEventListener('pageshow', function () {
            if (audioContext !== null && audioContext.state !== 'running') {
                audioContextUnlocked = false;
            }
        });
    }

    function playEffect(source, volume) {
        var finalVolume = typeof volume === 'number' ? volume : 0.2;

        if (!AudioContextClass) {
            var fallback = new Audio(source);
            fallback.volume = clampVolume(finalVolume * volumeToGain(effectsVolume));

            var fallbackPromise = fallback.play();

            if (fallbackPromise && typeof fallbackPromise.catch === 'function') {
                fallbackPromise.catch(function () {
                    // Old-browser fallback: blocked effects are intentionally dropped.
                });
            }

            return;
        }

        var context = getAudioContext(false);

        if (context !== null
            && context.state === 'running'
            && audioContextUnlocked) {
            playDecodedEffect(source, finalVolume);
            return;
        }

        /* Keep only the newest effect while the first gesture unlocks Web Audio. */
        pendingEffect = {
            source: source,
            volume: finalVolume,
            requestedAt: Date.now()
        };

        installUnlockListeners();

        if (navigator.userActivation && navigator.userActivation.isActive) {
            unlockAudioContext();
        }
    }

    function playSound(soundName, volume) {
        playEffect('/sounds/' + soundName + '.wav', volume);
    }

    function preloadEffect(source) {
        var context = getAudioContext(false);

        if (context === null
            || context.state !== 'running'
            || !audioContextUnlocked) {
            return;
        }

        loadEffectBuffer(source).catch(function () {
            // Optional preload failures must not interrupt the page.
        });
    }

    function preloadSound(soundName) {
        preloadEffect('/sounds/' + soundName + '.wav');
    }

    function playTrack(name, source, options) {
        var track = getTrack(name);
        var element = track.element;
        var settings = options || {};
        var volume = typeof settings.volume === 'number' ? settings.volume : 0.2;
        var loop = settings.loop === true;
        var queueUntilInteraction = settings.queueUntilInteraction !== false;

        track.baseVolume = clampVolume(volume);
        track.volumeGroup = settings.volumeGroup === 'jingle'
            ? 'jingle'
            : 'music';
        track.muted = settings.muted === true;

        /*
         * On iOS, never let a pre-interaction HTMLAudio track become audible
         * directly: its volume property is not a reliable volume control.
         */
        track.deferredForAudioGraph =
            deferTrackOutputUntilAudioGraph
            && !track.audioGraphReady
            && !track.audioGraphFailed
            && audioContext === null;

        if (audioContext !== null) {
            ensureTrackAudioGraph(track, audioContext);
        }

        element.pause();
        element.src = source;
        element.loop = loop;
        applyTrackOutputVolume(track);

        try {
            element.currentTime = 0;
        } catch (error) {
            // The media is not seekable until metadata is loaded.
        }

        element.load();
        track.pending = null;

        tryPlayTrack(track, queueUntilInteraction);
    }

    function resumeTrack(name, queueUntilInteraction) {
        var track = getTrack(name);
        var element = track.element;
        var source = element.getAttribute('src') || element.src;

        if (!source) {
            return;
        }

        tryPlayTrack(track, queueUntilInteraction !== false);
    }

    function pauseTrack(name) {
        var track = getTrack(name);
        track.pending = null;
        track.element.pause();
    }

    function stopTrack(name, clearSource) {
        var track = getTrack(name);
        var element = track.element;

        track.pending = null;
        element.pause();

        try {
            element.currentTime = 0;
        } catch (error) {
            // The media may not be seekable.
        }

        if (clearSource === true) {
            element.removeAttribute('src');
            element.load();
        }
    }

    function setTrackMuted(name, muted) {
        var track = getTrack(name);

        track.muted = muted === true;
        applyTrackOutputVolume(track);
    }

    function setTrackVolume(name, volume) {
        var track = getTrack(name);

        track.baseVolume = clampVolume(volume);

        if (audioContext !== null && !track.audioGraphReady) {
            ensureTrackAudioGraph(track, audioContext);
        }

        applyTrackOutputVolume(track);
    }

    function setMusicVolume(volume, saveToStorage) {
        musicVolume = clampVolume(volume);

        for (var name in tracks) {
            if (!Object.prototype.hasOwnProperty.call(tracks, name)) {
                continue;
            }

            var track = tracks[name];

            if (track.volumeGroup !== 'music') {
                continue;
            }

            if (audioContext !== null && !track.audioGraphReady) {
                ensureTrackAudioGraph(track, audioContext);
            }

            applyTrackOutputVolume(track);
        }

        if (saveToStorage !== false) {
            persistVolume(musicVolumeStorageKey, musicVolume);
        }
    }

    function setJingleVolume(volume, saveToStorage) {
        jingleVolume = clampVolume(volume);

        for (var name in tracks) {
            if (!Object.prototype.hasOwnProperty.call(tracks, name)) {
                continue;
            }

            var track = tracks[name];

            if (track.volumeGroup !== 'jingle') {
                continue;
            }

            if (audioContext !== null && !track.audioGraphReady) {
                ensureTrackAudioGraph(track, audioContext);
            }

            applyTrackOutputVolume(track);
        }

        if (saveToStorage !== false) {
            persistVolume(jingleVolumeStorageKey, jingleVolume);
        }
    }

    function setEffectsVolume(volume, saveToStorage) {
        effectsVolume = clampVolume(volume);

        for (var i = 0; i < activeEffects.length; i++) {
            activeEffects[i].gain.gain.value =
                activeEffects[i].baseVolume * volumeToGain(effectsVolume);
        }

        if (saveToStorage !== false) {
            persistVolume(effectsVolumeStorageKey, effectsVolume);
        }
    }

    function getMusicVolume() {
        return musicVolume;
    }

    function getJingleVolume() {
        return jingleVolume;
    }

    function getEffectsVolume() {
        return effectsVolume;
    }

    function stopAllEffects() {
        for (var i = 0; i < activeEffects.length; i++) {
            try {
                activeEffects[i].source.stop(0);
            } catch (error) {
                // The source may already have ended.
            }
        }

        activeEffects = [];
        pendingEffect = null;
    }

    installUnlockListeners();

    window.UCAudio = {
        createTrack: createTrack,
        getEffectsVolume: getEffectsVolume,
        getJingleVolume: getJingleVolume,
        getMusicVolume: getMusicVolume,
        pauseTrack: pauseTrack,
        resumeTrack: resumeTrack,
        playEffect: playEffect,
        playSound: playSound,
        playTrack: playTrack,
        preloadEffect: preloadEffect,
        preloadSound: preloadSound,
        setEffectsVolume: setEffectsVolume,
        setJingleVolume: setJingleVolume,
        setMusicVolume: setMusicVolume,
        setTrackMuted: setTrackMuted,
        setTrackVolume: setTrackVolume,
        stopAllEffects: stopAllEffects,
        stopTrack: stopTrack,
        unlock: unlock
    };

}(window, document));

