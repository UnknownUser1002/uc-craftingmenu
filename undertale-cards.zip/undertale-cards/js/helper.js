var effects = {};

var tribeDialogOpen = false;

function initHelper() {
    $(document).on('contextmenu', function (e) {
        if ($(e.target).hasClass("helpPointer")) {
            return false;
        }
    });
}

function setInfoPowers(monsterContainer, card) {

    monsterContainer.find('.cardStatus').empty();

    var powers = [];
    var powersStringKeys = [];
    var powersStringArgs = [];
    var powersStringNumbers = [];

    if (card.cost < card.originalCost) {
        powers.push("BonusCost");
        powersStringKeys.push('status-cost-debuff');
        powersStringArgs.push([card.originalCost]);
        powersStringNumbers.push(null);
    }

    if (card.cost > card.originalCost) {
        powers.push("MalusCost");
        powersStringKeys.push('status-cost-buff');
        powersStringArgs.push([card.originalCost]);
        powersStringNumbers.push(null);
    }

    if (card.rarity === "DETERMINATION") {
        powers.push("Determination");
        powersStringKeys.push('status-determination');
        powersStringArgs.push([]);
        powersStringNumbers.push(null);
    }

    if (card.typeCard === 0) {

        if (card.attack > card.originalAttack) {
            powers.push("BonusAtk");
            powersStringKeys.push('status-atk-buff');
            powersStringArgs.push([card.originalAttack]);
            powersStringNumbers.push(null);
        }

        if (card.attack < card.originalAttack) {
            powers.push("MalusAtk");
            powersStringKeys.push('status-atk-debuff');
            powersStringArgs.push([card.originalAttack]);
            powersStringNumbers.push(null);
        }

        if (card.maxHp > card.originalHp) {
            powers.push("BonusHp");
            powersStringKeys.push('status-hp-buff');
            powersStringArgs.push([card.originalHp]);
            powersStringNumbers.push(null);
        }

        if (card.maxHp < card.originalHp) {
            powers.push("MalusHp");
            powersStringKeys.push('status-hp-debuff');
            powersStringArgs.push([card.originalHp]);
            powersStringNumbers.push(null);
        }

        if (card.caughtMonster !== undefined) {
            powers.push("Box");
            powersStringKeys.push('status-caught');

            var caughtCardTranslated = $.i18n('{{CARD:' + card.caughtMonster.fixedId + '|1}}');
            powersStringArgs.push([caughtCardTranslated, card.caughtMonster.owner.username]);

            powersStringNumbers.push(null);
        }

        //Underevent
        if (card.fixedId === 874) {
            powers.push("Underevent2024");
            powersStringKeys.push('status-underevent-2024');
            powersStringArgs.push([]);
            powersStringNumbers.push(null);
        }
    }

    //NEW STATUS
    var statuses = card.statuses;

    if (statuses !== undefined) {
        for (var i = 0; i < statuses.length; i++) {
            var status = statuses[i];
            powers.push(status.name);
            powersStringKeys.push('status-' + toKebabCase(status.name).toLowerCase());

            var counter = status.displayCounter ? status.counter : 0;
            powersStringArgs.push([counter]);
            powersStringNumbers.push(counter);
        }
    }


    if (card.creatorInfo !== undefined && card.creatorInfo.typeCreator >= 0) {
        powers.push("Created");
        powersStringKeys.push('status-created');

        var creatorCardTranslated = '';

        // CARD
        if (card.creatorInfo.typeCreator === 0) {
            creatorCardTranslated = $.i18n('{{CARD:' + card.creatorInfo.id + '|1}}');
        }
        // ARTIFACT
        else if (card.creatorInfo.typeCreator === 1) {
            creatorCardTranslated = $.i18n('{{ARTIFACT:' + card.creatorInfo.id + '}}');
        }
        // SOUL
        else if (card.creatorInfo.typeCreator === 2) {
            creatorCardTranslated = $.i18n('{{SOUL:' + card.creatorInfo.name + '}}');
        }
        // ENCHANT
        else if (card.creatorInfo.typeCreator === 3) {
            creatorCardTranslated = $.i18n('{{ENCHANT:' + toKebabCase(card.creatorInfo.name) + '}}');
        }

        powersStringArgs.push([creatorCardTranslated]);

        powersStringNumbers.push(null);
    }

    for (var i = 0; i < powersStringArgs.length; i++) {
        var args = powersStringArgs[i];

        for (var j = 0; j < args.length; j++) {
            args[j] = base64EncodeUnicode(args[j]);
        }
    }

    var spacing = (powersStringKeys.length - 1) * 20 > 135 ? 135 / (powersStringKeys.length - 1) : 20;

    for (var i = 0; i < powersStringKeys.length; i++) {

        var $cardContainerImage = monsterContainer.find('.cardStatus');

        $cardContainerImage.append('<img style="right: ' + (i * spacing) + 'px;" power="' + powers[i] + '" class="infoPowers helpPointer" src="images/powers/' + powers[i] + '.png" oncontextmenu="displayStatusStringKey(' + formatArgs(powersStringKeys[i], powersStringArgs[i]) + '); return false;">');

        if (powersStringNumbers[i] !== null && powersStringNumbers[i] > 0) {
            $cardContainerImage.append('<span style="right: ' + (i * spacing) + 'px;" class="infoPowersDetails helpPointer" oncontextmenu="displayStatusStringKey(' + formatArgs(powersStringKeys[i], powersStringArgs[i]) + '); return false;">' + powersStringNumbers[i] + '</span>');
        }
    }

    var tribes = card.tribes;

    if (tribes.indexOf('ALL') > -1) {
        var $cardContainerImage = monsterContainer.find('.cardTribes');
        $cardContainerImage.append('<img style="right: 4px;" class="tribe helpPointer" src="images/tribes/ALL.png" oncontextmenu="showTribeCards(\'ALL\'); return false;"/>');
    } else {
        for (var i = 0; i < tribes.length; i++) {
            var cardContainerImage = monsterContainer.find('.cardTribes');
            cardContainerImage.append('<img style="right: ' + (i * 20) + 'px;" class="tribe helpPointer" src="images/tribes/' + tribes[i] + '.png" oncontextmenu="showTribeCards(\'' + tribes[i] + '\'); return false;"/>');
        }
    }

}

function formatArgs(key, stringArgs) {

    var finalString = "'" + key + "'";

    for (var i = 0; i < stringArgs.length; i++) {

        var arg = stringArgs[i];

        finalString += ", '";
        finalString += arg;
        finalString += "'";
    }

    return finalString;

}

function displayStatusStringKey() {

    var translateArguments = [];

    translateArguments.push(arguments[0]);

    if (arguments.length > 1) {

        for (var i = 1; i < arguments.length; i++) {
            translateArguments.push(atob(arguments[i]));
        }

    }

    var text = $.i18n.apply($.i18n, translateArguments);

    BootstrapDialog.show({
        title: $.i18n('dialog-information'),
        message: '<p>' + text + '</p>',
        buttons: [{
            label: $.i18n('dialog-ok'),
            cssClass: 'btn-primary',
            action: function (dialog) {
                dialog.close();
            }
        }]
    });
}

function displayStringKeyMessage(stringKey) {

    var params = Array.prototype.slice.call(arguments, 1);
    var titleArguments = [stringKey].concat(params.length > 0 ? params : [1]);
    var descriptionArguments = [stringKey + '-desc'].concat(params);

    var title = $.i18n.apply($.i18n, titleArguments);
    var message = $.i18n.apply($.i18n, descriptionArguments);

    BootstrapDialog.show({
        title: title,
        message: '<p>' + message + '</p>',
        buttons: [{
            label: $.i18n('dialog-ok'),
            cssClass: 'btn-primary',
            action: function (dialog) {
                dialog.close();
            }
        }]
    });
}

function soulInfo(soul) {

    var soulStringKey = 'soul-' + soul.replace('_', '-').toLowerCase();
    var soulDescStringKey = soulStringKey + '-desc';

    if (soul === 'MONSTER') {

        if (idFight > 0) {
            soulStringKey = soulStringKey + '-' + idFight;
            soulDescStringKey = soulStringKey + '-desc';
        }
    }

    var name = $.i18n(soulStringKey);
    var message = '<img src="images/souls/' + soul + '.png"/> <span class="' + soul + '">' + name + ' </span><br/><br/>' + $.i18n(soulDescStringKey);

    BootstrapDialog.show({
        title: name,
        message: '<p>' + message + '</p>',
        buttons: [{
            label: $.i18n('dialog-ok'),
            cssClass: 'btn-primary',
            action: function (dialog) {
                dialog.close();
            }
        }]
    });
}

function inGameSoulInfo(dataSoul) {

    var soul = JSON.parse(dataSoul);

    var soulStringKey = 'soul-' + soul.name.toLowerCase();
    var soulDescStringKey = soulStringKey + '-desc';

    if (soul.name === 'MONSTER') {
        soulDescStringKey = soulStringKey + '-' + soul.monster + '-desc';
    }

    var name = $.i18n(soulStringKey);
    var message = '<img src="images/souls/' + soul.name + '.png"/> <span class="' + soul.name + '">' + name + ' </span><br/><br/>' + $.i18n(soulDescStringKey);

    BootstrapDialog.show({
        title: name,
        message: '<p>' + message + '</p>',
        buttons: [{
            label: $.i18n('dialog-ok'),
            cssClass: 'btn-primary',
            action: function (dialog) {
                dialog.close();
            }
        }]
    });
}

function base64EncodeUnicode(str) {
    var utf8Bytes = encodeURIComponent(str).replace(/%([0-9A-F]{2})/g, function (match, p1) {
        return String.fromCharCode('0x' + p1);
    });

    return btoa(utf8Bytes);
}

function updateArtifactInfoProgress(idArtifact, progress, goal, artifactOwner) {

    if (idArtifact === undefined || idArtifact === null || idArtifact === '') {
        return;
    }

    var progressValue = Number(progress);
    var goalValue = Number(goal);

    if (!isFinite(progressValue)) {
        progressValue = 0;
    }

    if (!isFinite(goalValue)) {
        goalValue = 0;
    }

    var artifactId = String(idArtifact);
    var ownerKey = artifactOwner === undefined || artifactOwner === null
        ? ''
        : String(artifactOwner);

    $('.artifact-progress-dialog-value').filter(function () {
        return String($(this).attr('data-artifact-id')) === artifactId
            && String($(this).attr('data-artifact-owner') || '') === ownerKey;
    }).text(progressValue + '/' + goalValue);
}

function artifactInfo(idArtifact, progress, goal, artifactOwner) {

    var artifactName = $.i18n('artifact-name-' + idArtifact);
    var artifactDesc = $.i18n('artifact-' + idArtifact);
    var message = '<p>' + artifactDesc + '</p>';

    var hasProgress = progress !== undefined && progress !== null
        && goal !== undefined && goal !== null;

    if (hasProgress) {
        var progressValue = Number(progress);
        var goalValue = Number(goal);

        if (!isFinite(progressValue)) {
            progressValue = 0;
        }

        if (!isFinite(goalValue)) {
            goalValue = 0;
        }

        var ownerKey = artifactOwner === undefined || artifactOwner === null
            ? ''
            : String(artifactOwner);

        var safeArtifactId = $('<div>').text(String(idArtifact)).html();
        var safeOwnerKey = $('<div>').text(ownerKey).html();

        message += '<p class="artifact-progress-dialog">'
            + '<span class="artifact-progress-dialog-value"'
            + ' data-artifact-id="' + safeArtifactId + '"'
            + ' data-artifact-owner="' + safeOwnerKey + '">'
            + progressValue + '/' + goalValue
            + '</span></p>';
    }

    BootstrapDialog.show({
        title: artifactName,
        message: message,
        buttons: [{
            label: $.i18n('dialog-ok'),
            cssClass: 'btn-primary',
            action: function (dialog) {
                dialog.close();
            }
        }]
    });
}

function artifactsInfo(box) {

    if ($(box).find('.artifact-img').length > 0) {

        var text = "";

        $(box).find('.artifact-img').each(function () {

            var artifactId = $(this).attr("artifactId");
            var name = $.i18n('artifact-name-' + artifactId);
            var image = $(this).attr("image");
            var legendary = $(this).attr("legendary");

            if (legendary === "true") {
                name = '<span class="yellow">' + name + '</span>';
            }

            text = text + '<p><img style="height:32px;" src="images/artifacts/' + image + '.png"> ' + name + ' : ' + $.i18n('artifact-' + artifactId) + '</p>';

        });

        BootstrapDialog.show({
            title: $.i18n('dialog-information'),
            message: text,
            buttons: [{
                label: $.i18n('dialog-ok'),
                cssClass: 'btn-primary',
                action: function (dialog) {
                    dialog.close();
                }
            }]
        });

    }
}

function displayCardHelp(slot, idCard, shiny) {
    var position = $(slot).offset();
    showCardHover(idCard, shiny, position.left - 176, position.top - 190);
}

function showTribeCards(tribe) {

    if (!tribeDialogOpen) {
        if (allCards.length > 0) {

            var tribeCards = [];

            for (var i = 0; i < allCards.length; i++) {

                var card = allCards[i];

                if (card.tribes.indexOf(tribe) > -1) {
                    tribeCards.push(card);
                }
            }

            if (tribeCards.length > 0) {

                tribeDialogOpen = true;

                var tribeName = $.i18n('tribe-' + tribe.replace(/_/, '-').toLowerCase());

                var text = '<div id="tribeCards" class="container cardsPreview no-hover">';

                for (var i = 0; i < tribeCards.length; i++) {
                    var $tribeCard = appendCard(tribeCards[i], null);
                    $tribeCard.addClass('col-md-2');
                    $tribeCard.removeClass('pointer');
                    $tribeCard.find('.tribe').removeClass('helpPointer');
                    $tribeCard.find('.descTribe').removeClass('helpPointer');
                    text += $tribeCard.prop('outerHTML');
                }

                text += '</div>';

                BootstrapDialog.show({
                    title: tribeName,
                    size: BootstrapDialog.SIZE_WIDE,
                    message: text,
                    buttons: [{
                        label: $.i18n('dialog-ok'),
                        cssClass: 'btn-primary',
                        action: function (dialog) {
                            dialog.close();
                        }
                    }],
                    onhide: function (dialogRef) {
                        tribeDialogOpen = false;
                    }
                });
            }
        }
    }
}

function getResizedFontSize(container, maxHeight) {

    var fontSize = 12;
    var max = 10;

    var i = 0;

    var $clonedContainer = container.parent().clone();
    $clonedContainer.appendTo('body');

    $clonedContainer.css('font-size', fontSize + 'px');

    var $clonedContainerDiv = $clonedContainer.find('div');

    while ($clonedContainerDiv.outerHeight() >= maxHeight && i < max) {
        fontSize = fontSize - 0.5;
        $clonedContainer.css('font-size', fontSize + 'px');
        i++;
    }

    $clonedContainer.remove();

    return fontSize;

}

function cloneList(list) {

    var clonedList = [];

    for (var i = 0; i < list.length; i++) {
        var element = list[i];
        clonedList.push(JSON.parse(JSON.stringify(element)));
    }

    return clonedList;
}

function secondsToTime(timerSeconds) {

    var daysLeft = Math.trunc(timerSeconds / (24 * 3600));
    var hoursLeft = Math.trunc((timerSeconds - daysLeft * (24 * 3600)) / 3600);
    var minutesLeft = Math.trunc((timerSeconds - daysLeft * (24 * 3600) - hoursLeft * 3600) / 60);
    var secondsLeft = timerSeconds - daysLeft * (24 * 3600) - hoursLeft * 3600 - minutesLeft * 60;

    var displayedDays = daysLeft >= 10 ? daysLeft : ('0' + daysLeft);
    var displayedHours = hoursLeft >= 10 ? hoursLeft : ('0' + hoursLeft);
    var displayedMinutes = minutesLeft >= 10 ? minutesLeft : ('0' + minutesLeft);
    var displayedSeconds = secondsLeft >= 10 ? secondsLeft : ('0' + secondsLeft);

    if (daysLeft === 0) {
        return displayedHours + ':' + displayedMinutes + ':' + displayedSeconds;
    } else {
        return daysLeft + ':' + displayedHours + ':' + displayedMinutes + ':' + displayedSeconds;
    }
}

function compare(a, b) {
    if (a > b)
        return +1;
    if (a < b)
        return -1;
    return 0;
}

function getImagesAlts(string) {

    var imagesAlts = [];
    var imgRegex = /<img[^>]+alt=["']([^"']+)["'][^>]*>/gi;
    var match;

    while ((match = imgRegex.exec(string)) !== null) {
        var altText = match[1];
        var fixedAltText = altText.replace(/_/g, ' ');
        imagesAlts.push(fixedAltText.toLowerCase());
    }

    return imagesAlts;
}

function toKebabCase(str) {
    return str
        .replace(/([a-z0-9])([A-Z])/g, '$1-$2')
        .replace(/([A-Z])([A-Z][a-z])/g, '$1-$2')
        .toLowerCase();
}

initHelper();

