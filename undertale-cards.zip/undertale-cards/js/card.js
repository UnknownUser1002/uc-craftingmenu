/* global language, mobile, cardsVersion */

var themedSkin = null;

var shinyEnabled = localStorage.getItem("gameShinyDisabled") === null;

var breakingEnabled = localStorage.getItem("breakingDisabled") === null;

var allCards = [];

var cardHoverEnabled = true;

var allCardsEvent = new Event('allCardsReady');

function appendCardDeck(card) {

    var appendedCard = appendCard(card, $('#collection'));

    appendedCard.off("click").on("click", function (e) {
        var id = parseInt($(this).attr('id'));
        var shiny = $(this).hasClass('shiny');
        addCard(id, shiny);
    });

    appendedCard.append('<div class="cardQuantity">x <span class="nb">' + card.quantity + '</span></div>');

}

function appendCardCraft(card) {
    return appendCard(card, $('#collection'));
}

function appendCardFriendship(card, level, currentXp, maxXp) {

    var appendedCard = appendCard(card, $('#collection'));

    appendedCard.off("click").on("click", function (e) {
        showFriendshipRewards(card.fixedId);
    });

    var levelColors = ['#ff906d', '#dbdbdb', '#ffe455', '#67ff66', '#82fff5', '#ffb100', '#ff4d4d', '#9c22ff'];

    var color = levelColors[Math.min(Math.floor(level / 25), 7)];

    var divisionClasses = ['COPPER', 'IRON', 'GOLD', 'EMERALD', 'DIAMOND', 'MASTER', 'HIGH_MASTER', 'ULTIMATE_MASTER'];

    var division = divisionClasses[Math.min(Math.floor(level / 25), 7)];

    appendedCard.append('<div class="friendship-level" style="color: ' + color + '; border-color: ' + color + ';">' + level + '</div>');
    appendedCard.append('<div class="friendship-xp" style="color: ' + color + ';">' + currentXp + ' / ' + maxXp + '</div>');
    appendedCard.append('<div class="friendship-bar"><progress class="' + division + 'Bar" max="' + maxXp + '" value="' + currentXp + '"></progress></div>');

    return appendedCard;

}

function appendCardCardSkinShop(cardSkin, frameName) {
    var appendedCard = appendCard(getCard(cardSkin.cardId), $('.cardSkinList'));
    var cardSkinInfo = cardSkin.name + '<br/>' + '<span class="Artist">' + cardSkin.authorName + '</span>';
    appendedCard.find('.cardDesc div').html(cardSkinInfo);
    appendedCard.find('.cardImage').css('background', 'transparent url(\'' + REMOTE_IMAGE_HOST + '/images/' + cardSkin.image + '.png\') no-repeat');
    appendedCard.addClass('cardSkin').removeClass('undertale-frame').addClass(frameName.replace(/\s+/g, '-').toLowerCase() + '-frame');

    if (cardSkin.typeSkin === 0) {
        appendedCard.addClass('standard-skin');
    } else if (cardSkin.typeSkin === 1) {
        appendedCard.addClass('full-skin');
    } else if (cardSkin.typeSkin === 2) {
        appendedCard.addClass('breaking-skin');

        if (!breakingEnabled) {
            appendedCard.addClass('breaking-disabled');
        }
    }

    var ucpCost;

    if (cardSkin.owned) {
        appendedCard.addClass('owned');
        ucpCost = '<div class="cardUCPCost">' + $.i18n("cardskins-shop-owned") + '</div>';
    } else {

        var finalCost = cardSkin.ucpCost - cardSkin.discount;

        ucpCost = '<div class="cardUCPCost"><span class="ucp">' + finalCost + '</span> ' + $.i18n("item-ucp") + '</div>';
        appendedCard.off("click").on("click", function (e) {
            confirmPurchase(cardSkin.id);
        });
    }


    if (cardSkin.unavailable) {
        var $cardNameDiv = appendedCard.find('.cardName div');
        $cardNameDiv.prepend('<span class="glyphicon glyphicon-star yellow" title="Legacy"></span> ');
        $cardNameDiv.css('font-size', getResizedFontSize($cardNameDiv, 25));
    }

    if (cardSkin.discount > 0) {

        var percent = Math.floor((cardSkin.discount / cardSkin.ucpCost) * 100);

        var ucpDiscount = '<div class="cardUCPDiscount">-<span class="ucp">' + percent + '</span> %</div>';
        appendedCard.append(ucpDiscount);
    }

    appendedCard.append(ucpCost);

    return appendedCard;
}

function appendCardCardSkinProfile(card, container) {

    var appendedCard = appendCard(card, container);

    if (container !== null) {
        appendedCard.off("click").on("click", function (e) {
            actionCardSkinLocker(card.fixedId);
        });
    }

    var cardSkinInfo = '';

    var activeCardSkin = card.activeCardSkin;

    if (activeCardSkin !== null) {
        cardSkinInfo = activeCardSkin.name + '<br/>' + '<span class="Artist">' + activeCardSkin.authorName + '</span>';
    }

    appendedCard.find('.cardDesc div').html(cardSkinInfo);
    appendedCard.append('<div class="cardQuantity">x <span class="nb">' + card.quantity + '</span></div>');

    return appendedCard;


}

function appendCard(card, container) {

    var $htmlCard = $(createCard(card));

    $htmlCard.find('.cardImage').css('background', 'transparent url(\'' + REMOTE_IMAGE_HOST + '/images/' + card.image + '.png\') no-repeat');
    $htmlCard.find('.cardRarity').css('background', 'transparent url(\'' + REMOTE_IMAGE_HOST + '/images/' + card.extension + '_' + card.rarity + '.png\') no-repeat');

    if (container !== null) {
        container.append($htmlCard);
    }

    if (card.typeSkin === 0) {
        $htmlCard.addClass('standard-skin');
    } else if (card.typeSkin === 1) {
        $htmlCard.addClass('full-skin');
    } else if (card.typeSkin === 2) {
        $htmlCard.addClass('breaking-skin');

        if (!breakingEnabled) {
            $htmlCard.addClass('breaking-disabled');
        }
    }

    setInfoPowers($htmlCard, card);
    updateCardVisual($htmlCard, card);

    var $shinySlot = $htmlCard.find('.shinySlot');

    if (!card.shiny) {
        $shinySlot.remove();
    }

    if (shinyEnabled) {
        $shinySlot.addClass('animated');
    }

    var $cardNameDiv = $htmlCard.find('.cardName div');
    var $cardDescDiv = $htmlCard.find('.cardDesc div');

    $cardNameDiv.css('font-size', getResizedFontSize($cardNameDiv, 25));
    $cardDescDiv.css('font-size', getResizedFontSize($cardDescDiv, 81));

    return $htmlCard;
}


function createCard(card) {

    var name = $.i18n('card-name-' + card.fixedId, 1);
    var description = $.i18n('card-' + card.fixedId);
    var attack = "";
    var hp = "";
    var shiny = "";

    if (card.hasOwnProperty('attack')) {
        attack = card.attack;
        hp = card.hp;
    }

    if (card.shiny) {
        shiny = " shiny";
    }

    var frameSkinName = 'undertale';

    if (card.hasOwnProperty('frameSkinName')) {
        frameSkinName = card.frameSkinName.replace(/\s+/g, '-').toLowerCase();
    }

    frameSkinName += '-frame';

    var htmlCard = '<div id="' + card.id + '" class="card card-'+ card.fixedId +' monster ' + frameSkinName + shiny + '" data-rarity="' + card.rarity + '">\n\
    <div class="shinySlot"></div>\n\
    <div class="cardFrame"></div>\n\
    <div class="cardBackground"></div>\n\
    <div class="cardHeader"></div>\n\
    <div class="cardName"><div>' + name + '</div></div>\n\
    <div class="cardCost">' + card.cost + '</div>\n\
    <div class="cardStatus"></div>\n\
    <div class="cardTribes"></div>\n\
    <div class="cardAction"></div>\n\
    <div class="cardImage"></div>\n\
    <div class="cardSilence"></div>\n\
    <div class="cardDesc"><div>' + description + '</div></div>\n\
    <div class="cardFooter"></div>\n\
    <div class="cardATK">' + attack + '</div>\n\
    <div class="cardRarity"></div>\n\
    <div class="cardHP">' + hp + '</div></div>';

    if (card.typeCard === 1) {

        var cardSoul = card.hasOwnProperty('soul') ? card.soul.name : '';
        htmlCard = '<div id="' + card.id + '" class="card card-'+ card.fixedId +' spell ' + frameSkinName + ' ' + shiny + '" data-rarity="' + card.rarity + '">\n\
        <div class="shinySlot"></div>\n\
        <div class="cardFrame"></div>\n\
        <div class="cardBackground"></div>\n\
        <div class="cardHeader"></div>\n\
        <div class="cardName ' + cardSoul + '"><div>' + name + '</div></div>\n\
        <div class="cardCost">' + card.cost + '</div>\n\
        <div class="cardStatus"></div>\n\
        <div class="cardTribes"></div>\n\
        <div class="cardImage"></div>\n\
        <div class="cardDesc"><div>' + description + '</div></div>\n\
        <div class="cardFooter"></div>\n\
        <div class="cardRarity"></div>\n\
        </div>';
    }

    return htmlCard;
}

function initCards() {
    fetchCardsVersion();
}

function fetchCardsVersion() {

    var savedCardsVersion = localStorage.getItem("cardsVersion");
    var savedAllCards = localStorage.getItem("allCards");

    $.ajax({
        url: "Version?type=cards",
        type: "GET",
        contentType: "application/json",
        dataType: "json",
        success: function (data) {

            var cardsVersion = data.cardsVersion;

            if (savedCardsVersion === null || savedAllCards === null || parseInt(savedCardsVersion) !== cardsVersion) {
                fetchAllCards();
                localStorage.setItem("cardsVersion", cardsVersion);
            } else {
                allCards = JSON.parse(savedAllCards);
                document.dispatchEvent(allCardsEvent);
            }

        }
    });

}

function fetchAllCards() {

    $.ajax({
        url: "AllCards",
        type: "GET",
        contentType: "application/json",
        dataType: "json",
        success: function (data) {
            allCards = JSON.parse(data.cards);
            localStorage.setItem("allCards", JSON.stringify(allCards));
            document.dispatchEvent(allCardsEvent);
        },
        error: function (err) {
            localStorage.removeItem("allCards");
        }
    });

}

function showCardHover(idCard, shiny, x, y) {

    if (cardHoverEnabled) {

        if (allCards.length > 0) {

            removeCardHover();

            var realX = x;

            if (realX < 0) {
                realX += 330;
            }

            var realY = y;

            if (realY < 0) {
                realY = 0;
            }

            var div = '<div id="hover-card" style="position:absolute; left: ' + realX + 'px; top: ' + realY + 'px; z-index: 3000;"></div>';

            $('body').append(div);

            var card = getCard(idCard);

            card.shiny = shiny;

            var appendedCard = appendCard(card, $('#hover-card'));

            appendedCard.addClass('cardHover');

        }
    }


}

function removeCardHover() {
    $('#hover-card').remove();
}

function getCard(idCard) {

    for (var i = 0; i < allCards.length; i++) {

        var card = allCards[i];

        if (card.id === idCard) {
            return JSON.parse(JSON.stringify(card));
        }
    }

    return null;
}

function getCardWithName(cardName) {

    for (var i = 0; i < allCards.length; i++) {

        var card = allCards[i];

        if (card.name === cardName) {
            return card;
        }
    }

    return null;
}

function updateCardVisual($htmlCard, card) {

    var $cardCost = $htmlCard.find('.cardCost');
    $cardCost.html(card.cost);
    $cardCost.removeClass('cost-buff').removeClass('cost-debuff');

    if (card.cost > card.originalCost) {
        $cardCost.addClass('cost-debuff');
    } else if (card.cost < card.originalCost) {
        $cardCost.addClass('cost-buff');
    }

    var $cardHP = $htmlCard.find('.cardHP');
    $cardHP.html(card.hp);

    if (card.hp < card.maxHp) {
        $cardHP.removeClass('damaged').addClass('damaged');
    } else {
        $cardHP.removeClass('damaged');

        if (card.maxHp > card.originalHp) {
            $cardHP.removeClass('hp-buff').addClass('hp-buff');
        } else {
            $cardHP.removeClass('hp-buff');
        }
    }

    var $cardATK = $htmlCard.find('.cardATK');
    $cardATK.html(card.attack);

    if (hasStatus(card, 'Paralyzed')) {
        $htmlCard.removeClass('paralyzed').addClass('paralyzed');
    } else {
        $htmlCard.removeClass('paralyzed');

        $cardATK.removeClass('attack-buff').removeClass('attack-debuff');

        if (card.attack > card.originalAttack) {
            $cardATK.addClass('attack-buff');
        } else if (card.attack < card.originalAttack) {
            $cardATK.addClass('attack-debuff');
        }
    }

    if (hasStatus(card, 'Silenced')) {
        $htmlCard.find('.cardSilence').css('background', 'transparent url(\'' + REMOTE_IMAGE_HOST + '/images/silence.png\') no-repeat');
    }
    else {
        $htmlCard.find('.cardSilence').css('background', 'none')
    }
}

function hasStatus(card, statusName) {
    if (!card || !Array.isArray(card.statuses)) {
        return false; // sécurité si card ou card.statuses est invalide
    }

    return card.statuses.some(status => status.name === statusName);
}

function getStatusCounter(card, statusName) {
    if (!card || !Array.isArray(card.statuses)) {
        return -1; // sécurité
    }

    const status = card.statuses.find(s => s.name === statusName);
    return status ? status.counter : -1;
}

initCards();

