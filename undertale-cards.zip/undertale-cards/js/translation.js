var availableLanguages = ["en", "fr", "es", "pt", "cn", "it", "pl", "de", "ru"];

var tipsGeneratorId = 0;

var translationReady = false;

var translationEvent = new Event('translationReady');

const card_number_color_classes = ['cost-color', 'atk-color', 'hp-color'];
const card_number_regex = /[\d\.\,]+/gm;

function loadTranslation(language) {

    var langs = ["en"];
    langs.push(language);

    var languagesObject = {};

    for (var i = 0; i < langs.length; i++) {
        var lang = langs[i];
        languagesObject[lang] = 'translation/' + lang + '.json?v=' + translateVersion
    }

    $.i18n().debug = false;
    $.i18n().locale = language;
    $.i18n().load(languagesObject).done(function () {
        $.extend($.i18n.parser.emitter, {
            ucp: function (nodes) {
                return '<span class="ucp">' + nodes[0] + '</span>';
            },
            tribe: function (nodes) {
                if (nodes.length > 0) {
                    var quantity = 1;
                    if (nodes.length === 2) {
                        quantity = nodes[1];
                    }

                    var tribeStringKey = 'tribe-' + nodes[0].toLowerCase().replace(/_/g, '-');
                    var text = '';
                    var overrideText = checkOverride(nodes);

                    if (overrideText === null) {
                        text = $.i18n(tribeStringKey, quantity);
                    } else {
                        text = overrideText;
                    }

                    return '<span class="underlined pointer helpPointer" '
                        + 'onclick="return handleTranslatedInfoClick(event, this, \'showTribeCards\', [\'' + nodes[0] + '\']);" '
                        + 'oncontextmenu="return handleTranslatedInfoContextMenu(event, this, \'showTribeCards\', [\'' + nodes[0] + '\']);">'
                        + text
                        + '</span>';
                }
            },
            soul: function (nodes) {
                if (nodes.length > 0) {
                    var soul = nodes[0];
                    var soulStringKey = 'soul-' + soul.replace(/_/g, '-').toLowerCase();

                    var text = '';
                    var overrideText = checkOverride(nodes);

                    if (overrideText === null) {
                        text = $.i18n(soulStringKey);
                    } else {
                        text = overrideText;
                    }

                    return '<span class="' + soul + ' pointer helpPointer" '
                        + 'onclick="return handleTranslatedInfoClick(event, this, \'soulInfo\', [\'' + soul + '\']);" '
                        + 'oncontextmenu="return handleTranslatedInfoContextMenu(event, this, \'soulInfo\', [\'' + soul + '\']);">'
                        + text
                        + '</span>';
                }
            },
            kw: function (nodes) {
                if (nodes.length > 0) {
                    var keyword = nodes[0];
                    var keywordClean = keyword.replace(/_/g, '-').toLowerCase();
                    var keywordStringKey = 'kw-' + keywordClean;

                    var overrideText = checkOverride(nodes);
                    var text = overrideText || $.i18n(keywordStringKey);

                    return '<span class="kw-' + keywordClean + ' pointer helpPointer underlined" '
                        + 'onclick="return handleTranslatedInfoClick(event, this, \'displayStringKeyMessage\', [\'' + keywordStringKey + '\']);" '
                        + 'oncontextmenu="return handleTranslatedInfoContextMenu(event, this, \'displayStringKeyMessage\', [\'' + keywordStringKey + '\']);">'
                        + text
                        + '</span>';
                }
            },
            artifact: function (nodes) {
                if (nodes.length > 0) {
                    var artifactId = nodes[0];
                    var artifactNameKey = 'artifact-name-' + artifactId;

                    var overrideText = checkOverride(nodes);
                    var text = overrideText || $.i18n(artifactNameKey);

                    return '<span class="pointer helpPointer underlined" '
                        + 'onclick="return handleTranslatedInfoClick(event, this, \'artifactInfo\', [' + artifactId + ']);" '
                        + 'oncontextmenu="return handleTranslatedInfoContextMenu(event, this, \'artifactInfo\', [' + artifactId + ']);">'
                        + text
                        + '</span>';
                }
            },
            quest: function (nodes) {
                if (nodes.length > 0) {
                    var questId = parseInt(nodes[0], 10);

                    if (!isFinite(questId)) {
                        return '';
                    }

                    var questNameKey = 'artifact-name-' + questId;
                    var overrideText = checkOverride(nodes);
                    var text = overrideText || $.i18n(questNameKey);

                    return '<span class="pointer helpPointer underlined" '
                        + 'onclick="return handleTranslatedInfoClick(event, this, \'openQuestInfo\', [' + questId + ']);" '
                        + 'oncontextmenu="return handleTranslatedInfoContextMenu(event, this, \'openQuestInfo\', [' + questId + ']);">'
                        + text
                        + '</span>';
                }

                return '';
            },
            enchant: function (nodes) {
                if (nodes.length > 0) {

                    var keyword = nodes[0];
                    var keywordClean = keyword.replace(/_/g, '-').toLowerCase();
                    var keywordStringKey = 'enchant-' + keywordClean;

                    var text = '';

                    var overrideText = checkOverride(nodes);

                    if (overrideText === null) {
                        var quantity = 1;
                        if (nodes.length > 1) {
                            var arg = nodes[1];
                            if (!isNaN(arg)) {
                                quantity = parseInt(arg);
                            }
                        }
                        text = $.i18n(keywordStringKey, quantity);
                    } else {
                        text = overrideText;
                    }

                    return '<span class="enchant-' + keywordClean + ' pointer helpPointer underlined" '
                        + 'onclick="return handleTranslatedInfoClick(event, this, \'displayStringKeyMessage\', [\'' + keywordStringKey + '\']);" '
                        + 'oncontextmenu="return handleTranslatedInfoContextMenu(event, this, \'displayStringKeyMessage\', [\'' + keywordStringKey + '\']);">'
                        + text
                        + '</span>';
                }
            },
            hp: StatHelper("stat-hp", "hp-color"),
            atk: StatHelper("stat-atk", "atk-color"),
            gold: StatHelper("stat-gold", "yellow"),
            cost: StatHelper("stat-cost", "cost-color"),
            dmg: StatHelper("stat-dmg", "dmg-color"),
            kr: function (nodes) {
                var overrideText = checkOverride(nodes);
                var text = overrideText || $.i18n('stat-kr');
                return '<span class="PERSEVERANCE pointer helpPointer" '
                    + 'onclick="return handleTranslatedInfoClick(event, this, \'displayStatusStringKey\', [\'status-kr\', []]);" '
                    + 'oncontextmenu="return handleTranslatedInfoContextMenu(event, this, \'displayStatusStringKey\', [\'status-kr\', []]);">'
                    + text
                    + '</span>';
            },
            card: function (nodes) {
                if (nodes.length > 0) {
                    var idCard = parseInt(nodes[0]);
                    var text = '';
                    var overrideText = checkOverride(nodes);
                    if (overrideText === null) {
                        var quantity = 1;
                        if (nodes.length > 1) {
                            var arg = nodes[1];
                            if (!isNaN(arg)) {
                                quantity = parseInt(arg);
                            }
                        }
                        text = $.i18n('card-name-' + idCard, quantity);
                    } else {
                        text = overrideText;
                    }


                    return '<span onmouseover="displayCardHelp(this, ' + idCard + ');" onmouseleave="removeCardHover();" class="PATIENCE">' + text + '</span>';
                }
            },
            mode: function (nodes) {
                if (nodes.length === 1) {
                    var mode = nodes[0];
                    var stringKey = 'game-type-' + mode.replace(/_/g, '-').toLowerCase();
                    return $.i18n(stringKey);
                }
            },
            rarity: function (nodes) {
                if (nodes.length >= 1) {
                    var rarity = nodes[0];
                    var stringKey = 'rarity-' + rarity.replace(/_/g, '-').toLowerCase();

                    var overrideText = checkOverride(nodes);
                    var text = overrideText || $.i18n(stringKey);

                    var rarityText = '<span class="' + rarity + '">' + text + '</span>';
                    if (nodes.length == 1 || (nodes.length == 2 && overrideText)) {
                        return rarityText;
                    }
                    var icon = `<span class="rarityImageContainer"><img style="height: 1.5em;" src="/images/rarity/${nodes[1]}_${nodes[0]}.png"><span class="rarityImageHover"><span style="padding: 0.2em 0.5em;">${rarityText}</span><span class="rarityImageHoverArrow"></span></span></span>`;
                    return icon;
                }
            },
            division: function (nodes) {
                if (nodes.length > 0) {
                    var full = nodes.length === 2 && nodes[1] === "full";
                    var short = nodes.length === 2 && nodes[1] === "short";
                    var division = nodes[0];

                    if (!division) {
                        return "";
                    }

                    // Supporte "COPPER_III", "COPPER III", "Copper III"
                    var divisionKey = division
                        .toString()
                        .trim()
                        .toUpperCase()
                        .replaceAll(" ", "_");

                    var grade = "";

                    if (divisionKey.endsWith("_III")) {
                        grade = " III";
                    } else if (divisionKey.endsWith("_II")) {
                        grade = " II";
                    } else if (divisionKey.endsWith("_I")) {
                        grade = " I";
                    }

                    var divisionNameKey = divisionKey
                        .replace("_III", "")
                        .replace("_II", "")
                        .replace("_I", "")
                        .toLowerCase()
                        .replaceAll("_", "-");

                    var rank = divisionNameKey
                        .toUpperCase()
                        .replaceAll("-", "_");

                    var imgPath = "/images/divisions/" + divisionKey + ".png";

                    var iconClass = "divisionIcon divisionIcon-" + divisionKey.toLowerCase().replaceAll("_", "-");

                    if (short) {
                        iconClass += " divisionIconShort";
                    }

                    if (full) {
                        iconClass += " divisionIconFull";
                    }

                    var icon = ''
                        + '<img '
                        + 'src="' + imgPath + '" '
                        + 'alt="' + divisionKey + '" '
                        + 'title="' + divisionKey.replaceAll("_", " ") + '" '
                        + 'class="' + iconClass + '" '
                        + '/>';

                    if (full) {
                        return icon
                            + ' <span class="' + rank + '_COLOR divisionName">'
                            + $.i18n('division-' + divisionNameKey)
                            + grade
                            + '</span>';
                    }

                    return icon;
                }

                return "";
            },
            cosmetic: function (nodes) {
                if (nodes.length === 2) {
                    var cosmetic = nodes[0];
                    var name = nodes[1];
                    return $.i18n('reward-' + cosmetic) + ' - ' + name;
                }
            },
            style: function (nodes) {
                return `<span class="${nodes[0]}">${nodes[1]}</span>`;
            },
            switch_left: SwitchPartHelper("Left"),
            switch_right: SwitchPartHelper("Right"),
            stats: (nodes) => {
                if (nodes.length < 2 || nodes.length > 3) {
                    return "<span class='rainbowText'>ERROR!</span>";
                }
                for (var i = nodes.length - 1; i >= 0; i--) {
                    var color_class = card_number_color_classes[i + (card_number_color_classes.length - nodes.length)];
                    nodes[i] = nodes[i].replaceAll(card_number_regex, (number) => `<span class="${color_class}">${number}</span>`);
                }
                return nodes.join("/");
            },
            image: function (nodes) {
                if (nodes.length >= 2) {

                    var imageName = nodes[0];
                    var alt = nodes[1];

                    var width = 64;
                    var height = 16;
                    var idCard = 0;

                    if (nodes.length >= 3) {
                        width = nodes[2];
                    }
                    if (nodes.length >= 4) {
                        height = nodes[3];
                    }
                    if (nodes.length >= 5) {
                        idCard = nodes[4];
                    }

                    var img = '/images/inserted/' + imageName + '.png';

                    var $img;

                    if (idCard > 0) {
                        $img = '<span><img style="width: ' + width + 'px; height: ' + height + 'px;" class="inserted-img" onmouseover="displayCardHelp(this, ' + idCard + ');" onmouseleave="removeCardHover();" src="' + img + '" alt="' + alt + '"/></span>';
                    } else {
                        $img = '<span><img style="width: ' + width + 'px; height: ' + height + 'px;" class="inserted-img" src="' + img + '" alt="' + alt + '"/></span>';
                    }

                    return $img;
                }
            }
        });

        $('body').i18n();

        $("[data-i18n-custom]").each(function () {
            translateElement($(this));
        });

        $("[data-i18n-value]").each(function () {
            translateElement($(this));
        });

        $("[data-i18n-title]").each(function () {
            translateElement($(this));
        });

        $("[data-i18n-placeholder]").each(function () {
            translateElement($(this));
        });


        $("[data-i18n-tips]").each(function () {

            var $this = $(this);

            var customClass = 'tips-' + tipsGeneratorId;

            $this.addClass(customClass);

            var tipsMessage = $.i18n($this.attr('data-i18n-tips'));

            tippy('.' + customClass, {
                content: tipsMessage
            });
        });

        translationReady = true;
        document.dispatchEvent(translationEvent);

    });
}

function isTranslatedInfoInsideCard(element) {
    return element !== undefined
        && element !== null
        && $(element).closest('.card').length > 0;
}

function callTranslatedInfoAction(actionName, args) {
    var action = window[actionName];

    if (typeof action === 'function') {
        action.apply(null, args || []);
    }
}

function handleTranslatedInfoClick(event, element, actionName, args) {

    /*
     * Sur une carte, le clic gauche doit rester disponible pour jouer,
     * attaquer ou choisir une cible.
     */
    if (isTranslatedInfoInsideCard(element)) {
        return true;
    }

    event.preventDefault();
    event.stopPropagation();

    callTranslatedInfoAction(actionName, args);
    return false;
}

function handleTranslatedInfoContextMenu(event, element, actionName, args) {

    /*
     * Le clic droit ouvre toujours l'information :
     * - sur une carte, c'est le seul clic qui ouvre le popup ;
     * - hors carte, clic gauche et clic droit sont tous les deux autorisés.
     */
    event.preventDefault();
    event.stopPropagation();

    callTranslatedInfoAction(actionName, args);
    return false;
}

function openQuestInfo(idArtifact) {

    var artifactId = String(idArtifact);

    var $quest = $('.quest-progress').filter(function () {
        return String($(this).attr('data-artifact-info-id')) === artifactId
            || String($(this).attr('data-artifact-id')) === artifactId;
    }).first();

    if ($quest.length > 0) {
        artifactInfo(
            idArtifact,
            $quest.attr('data-progress'),
            $quest.attr('data-goal'),
            $quest.attr('data-artifact-owner')
        );
        return;
    }

    artifactInfo(idArtifact);
}

function translateElement(element) {

    if (element.attr('data-i18n-custom')) {

        var finalArgs = [];
        var stringKey = element.attr('data-i18n-custom');
        var args = element.attr('data-i18n-args').split(',');

        finalArgs.push(stringKey);

        for (var i = 0; i < args.length; i++) {
            var arg = args[i];
            if (!isNaN(arg)) {
                finalArgs.push(parseInt(arg));
            } else {
                finalArgs.push(arg)
            }
        }

        element.html($.i18n.apply($.i18n, finalArgs));
    } else if (element.attr('data-i18n-value')) {
        element.attr('value', htmlDecode($.i18n(element.attr('data-i18n-value'))));
    } else if (element.attr('data-i18n-placeholder')) {
        element.attr('placeholder', htmlDecode($.i18n(element.attr('data-i18n-placeholder'))));
    } else if (element.attr('data-i18n-title')) {
        element.attr('title', htmlDecode($.i18n(element.attr('data-i18n-title'))));
    } else {
        element.i18n();
    }
}

function translateFromServerJson(message) {
    var jMessage = JSON.parse(message);
    if (jMessage.hasOwnProperty('args')) {
        var args = JSON.parse(jMessage.args);
        return $.i18n.apply($.i18n, args);
    }
}

function getLanguage() {
    var userLanguage = window.navigator.language.substring(0, 2);
    var storedLanguage = localStorage.getItem('language');
    var finalLanguage;

    if (typeof Android !== 'undefined') {
        userLanguage = Android.getCountryCode();
    }

    if (storedLanguage !== null) {
        finalLanguage = storedLanguage;
    } else {
        finalLanguage = userLanguage;
    }

    localStorage.setItem('language', finalLanguage);

    return finalLanguage;
}

function checkOverride(nodes) {

    for (var i = 0; i < nodes.length; i++) {

        var node = nodes[i].toString();

        if (node.startsWith("override=")) {

            var splitValues = node.split('=');

            if (splitValues.length > 1) {
                return splitValues[1];
            }
        }
    }

    return null;
}

function htmlDecode(input) {
    var e = document.createElement('div');
    e.innerHTML = input;
    return e.childNodes.length === 0 ? "" : e.childNodes[0].nodeValue;
}

// elytrafae additions //

// Ok, Feildmaster gave me ideas to clean this one up
function SwitchPartHelper(dir) {
    return (nodes) => {
        const text = nodes[1];
        const opacity = isNaN(Number(nodes[0])) ? 1 : Number(nodes[0]);
        const classes = [`SwitchHighlight_${dir}`];
        if (opacity <= 0) {
            classes.push('invisible');
        }
        return `<span class="${classes.join(" ")}">${text}</span>`;
    }
}

function StatHelper(translation_key, textClass) {
    return (nodes) => {
        var finalText = '', number = 1;
        if (nodes.length > 0) {
            number = nodes[0];
            finalText = number + ' ';
        }

        var text = '';
        var overrideText = checkOverride(nodes);

        if (overrideText === null) {
            text = `<span class="${textClass}">${$.i18n(translation_key, number)}</span>`;
        } else {
            text = `<span class="${textClass}">${overrideText}</span>`;
        }

        finalText += text;
        return finalText;
    }
}

///////////////////////////

loadTranslation(getLanguage());