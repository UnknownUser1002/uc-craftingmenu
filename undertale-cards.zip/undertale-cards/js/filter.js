/* global mobile, humanize, language, colorDesc, allCards, translationReady */

var currentPage = 0;
var collection = [];
var pages = [];
var sortRules = []; // [{stat:'atk'|'hp'|'cost'|'ratio'|'valueEfficiency', dir:'desc'|'asc', num, den}], top = highest priority

function tryInitCollection() {
    if (allCards.length > 0 && translationReady) {
        initCollection();
    }
}

if (!(allCards.length > 0)) {
    document.addEventListener('allCardsReady', tryInitCollection);
}

if (!translationReady) {
    document.addEventListener('translationReady', tryInitCollection);
}

tryInitCollection();

function initCollection() {
    collection = cloneList(allCards);
    applyFilters();
    showPage(0);
}

$(document).ready(function () {

    document.getElementById('collection').addEventListener('wheel', function (e) {

        e.preventDefault();
        e.stopPropagation();

        if (e.deltaY > 0) {
            nextPage();
        } else if (e.deltaY < 0) {
            previousPage();
        }
    });

    $('#searchInput').keyup(function () {
        applyFilters();
        showPage(0);
    });

});

function applyFilters() {

    pages = [];

    var filteredCollection = cloneList(collection);

    //Filters

    for (var i = filteredCollection.length - 1; i >= 0; i--) {

        var card = filteredCollection[i];

        if (isRemoved(card)) {
            filteredCollection.splice(i, 1);
        }
    }

    //Sort (applied after filtering, on top of whatever passed the filters above)
    if (sortRules.length > 0) {
        filteredCollection.sort(compareBySortRules);
    }

    for (var i = 0; i < filteredCollection.length; i++) {
        pages.push(filteredCollection[i]);
    }

    $('#maxPage').html(getMaxPage() + 1);

}


function nextPage() {

    if (currentPage < getMaxPage()) {
        currentPage++;

        showPage(currentPage);
        $('#currentPage').html(currentPage + 1);
    }
}

function previousPage() {

    if (currentPage > 0) {
        currentPage--;

        showPage(currentPage);
        $('#currentPage').html(currentPage + 1);
    }

}

function showPage(page) {

    currentPage = page;

    $('#collection').empty();

    var currPage = page * 10;

    for (var i = currPage; i < currPage + 10; i++) {

        if (pages.length > i) {
            var card = pages[i];
            appendCardCraft(card);
        }
    }

    $('#currentPage').html(currentPage + 1);

    $('#btnNext').prop('disabled', page >= getMaxPage());
    $('#btnPrevious').prop('disabled', page === 0);

}

function existPage(page) {
    return page >= 0 && page <= getMaxPage();
}

function getMaxPage() {
    return Math.floor((pages.length - 1) / 10);
}

function isRemoved(card) {

    var removed = false;

    //Shiny
    removed = card.shiny !== $('#shinyInput').prop('checked');

    //Rarity
    if (!removed) {

        var rarities = [];

        $(".rarityInput").each(function (index) {
            if ($(this).prop('checked')) {
                rarities.push($(this).attr('rarity'));
            }
        });

        if (rarities.length > 0) {
            removed = !rarities.includes(card.rarity);
        }

    }

    //Type
    if (!removed) {

        var monster = $('#monsterInput').prop('checked');
        var spell = $('#spellInput').prop('checked');

        if (monster && !spell) {
            removed = card.typeCard !== 0;
        } else if (!monster && spell) {
            removed = card.typeCard !== 1;
        }

    }

    //Extension
    if (!removed) {

        var undertale = $('#undertaleInput').prop('checked');
        var deltarune = $('#deltaruneInput').prop('checked');
        var uty = $('#utyInput').prop('checked');
        var checkedExtensions = [];

        if (undertale) {
            checkedExtensions.push("BASE");
        }

        if (deltarune) {
            checkedExtensions.push("DELTARUNE");
        }

        if (uty) {
            checkedExtensions.push("UTY")
        }

        if (checkedExtensions.length > 0) {
            removed = checkedExtensions.indexOf(card.extension) === -1;
        }
    }

    //ATK / HP / Cost ranges (min and/or max, either can be left blank).
    //Spells have no attack/hp, so setting a constraint on those stats excludes them.
    if (!removed) {
        removed = isOutsideStatRange(card, 'attack', '#atkMinInput', '#atkMaxInput');
    }
    if (!removed) {
        removed = isOutsideStatRange(card, 'hp', '#hpMinInput', '#hpMaxInput');
    }
    if (!removed) {
        removed = isOutsideStatRange(card, 'cost', '#costMinInput', '#costMaxInput');
    }

    //Search

    if (!removed) {
        var searchValue = $('#searchInput').val().toLowerCase();

        if (searchValue.length > 0) {
            var findableString = "";

            findableString += $.i18n('card-name-' + card.id, 1);
            findableString += $.i18n('card-' + card.id);

            for (var i = 0; i < card.tribes.length; i++) {
                var tribe = card.tribes[i];
                findableString += $.i18n('tribe-' + tribe.toLowerCase().replace(/_/g, '-'));
            }

            if (card.hasOwnProperty('soul')) {
                findableString += $.i18n('soul-' + card.soul.name.toLowerCase().replace(/_/g, '-'));
            }

            var imageNames = getImagesAlts(findableString);
            var finalString = findableString.toLowerCase().replace(/(<.*?>)/g, '');
            finalString += ' ' + imageNames.join(' ');
            removed = !finalString.toLowerCase().includes(searchValue);
        }
    }

    return removed;
}

function isOutsideStatRange(card, field, minSelector, maxSelector) {
    var min = parseFloat($(minSelector).val());
    var max = parseFloat($(maxSelector).val());
    var hasMin = !isNaN(min);
    var hasMax = !isNaN(max);

    if (!hasMin && !hasMax) {
        return false; // no constraint set on this stat
    }
    if (!card.hasOwnProperty(field)) {
        return true; // e.g. a spell has no attack/hp, so it can't satisfy a constraint on it
    }

    var value = card[field];
    if (hasMin && value < min) {
        return true;
    }
    if (hasMax && value > max) {
        return true;
    }
    return false;
}

// ---- Sorting -------------------------------------------------------------
// Cards missing the relevant stat (spells have no attack/hp) always sort to the
// bottom, regardless of sort direction, rather than being treated as zero.

function statValue(card, stat) {
    if (stat === 'atk') {
        return card.hasOwnProperty('attack') ? card.attack : null;
    }
    if (stat === 'hp') {
        return card.hasOwnProperty('hp') ? card.hp : null;
    }
    if (stat === 'cost') {
        return card.hasOwnProperty('cost') ? card.cost : null;
    }
    return null;
}

function ruleValue(card, rule) {
    if (rule.stat === 'ratio') {
        var num = statValue(card, rule.num);
        var den = statValue(card, rule.den);
        if (num === null || den === null || den === 0) {
            return null;
        }
        return num / den;
    }
    if (rule.stat === 'valueEfficiency') {
        // Cost / (HP / ATK), i.e. cost per unit of "HP per ATK" -- lower is more efficient.
        var atk = statValue(card, 'atk');
        var hp = statValue(card, 'hp');
        var cost = statValue(card, 'cost');
        if (atk === null || hp === null || cost === null || hp === 0) {
            return null;
        }
        return cost / (hp / atk);
    }
    return statValue(card, rule.stat);
}

function compareBySortRules(a, b) {
    for (var i = 0; i < sortRules.length; i++) {
        var rule = sortRules[i];
        var va = ruleValue(a, rule);
        var vb = ruleValue(b, rule);

        if (va === null && vb === null) {
            continue;
        }
        if (va === null) {
            return 1;
        }
        if (vb === null) {
            return -1;
        }
        if (va !== vb) {
            return rule.dir === 'desc' ? (vb - va) : (va - vb);
        }
        // tied on this key -> fall through to the next rule
    }
    return 0;
}

// ---- Sort rule builder UI -------------------------------------------------

var SORT_STAT_OPTIONS = [
    ['atk', 'ATK'],
    ['hp', 'HP'],
    ['cost', 'Cost'],
    ['ratio', 'Custom ratio (stat \u00F7 stat)'],
    ['valueEfficiency', 'Cost \u00F7 (HP \u00F7 ATK)']
];
var RATIO_STAT_OPTIONS = [['atk', 'ATK'], ['hp', 'HP'], ['cost', 'Cost']];

function addSortRule() {
    sortRules.push({stat: 'cost', dir: 'asc', num: 'atk', den: 'cost'});
    renderSortRules();
    applyFilters();
    showPage(0);
}

function removeSortRule(index) {
    sortRules.splice(index, 1);
    renderSortRules();
    applyFilters();
    showPage(0);
}

function moveSortRule(index, delta) {
    var newIndex = index + delta;
    if (newIndex < 0 || newIndex >= sortRules.length) {
        return;
    }
    var tmp = sortRules[index];
    sortRules[index] = sortRules[newIndex];
    sortRules[newIndex] = tmp;
    renderSortRules();
    applyFilters();
    showPage(0);
}

function updateSortRule(index, field, value) {
    sortRules[index][field] = value;
    renderSortRules(); // re-render so ratio sub-fields show/hide correctly
    applyFilters();
    showPage(0);
}

function buildSelect(options, value, onChange) {
    var $select = $('<select class="form-control sortRuleControl"></select>');
    options.forEach(function (opt) {
        $select.append($('<option></option>').val(opt[0]).text(opt[1]));
    });
    $select.val(value);
    $select.on('change', function () {
        onChange($(this).val());
    });
    return $select;
}

function renderSortRules() {
    var $list = $('#sortRulesList');
    $list.empty();

    sortRules.forEach(function (rule, index) {
        var $row = $('<div class="sortRuleRow"></div>');

        $row.append(buildSelect(SORT_STAT_OPTIONS, rule.stat, function (val) {
            updateSortRule(index, 'stat', val);
        }));

        if (rule.stat === 'ratio') {
            var $ratioWrap = $('<span class="sortRatioFields"></span>');
            $ratioWrap.append(buildSelect(RATIO_STAT_OPTIONS, rule.num, function (val) {
                updateSortRule(index, 'num', val);
            }));
            $ratioWrap.append(' \u00F7 ');
            $ratioWrap.append(buildSelect(RATIO_STAT_OPTIONS, rule.den, function (val) {
                updateSortRule(index, 'den', val);
            }));
            $row.append($ratioWrap);
        }

        $row.append(buildSelect([['desc', 'High \u2192 Low'], ['asc', 'Low \u2192 High']], rule.dir, function (val) {
            updateSortRule(index, 'dir', val);
        }));

        var $upBtn = $('<button type="button" class="btn btn-default btn-xs" title="Higher priority">\u25B2</button>');
        $upBtn.prop('disabled', index === 0);
        $upBtn.on('click', function () {
            moveSortRule(index, -1);
        });
        $row.append($upBtn);

        var $downBtn = $('<button type="button" class="btn btn-default btn-xs" title="Lower priority">\u25BC</button>');
        $downBtn.prop('disabled', index === sortRules.length - 1);
        $downBtn.on('click', function () {
            moveSortRule(index, 1);
        });
        $row.append($downBtn);

        var $removeBtn = $('<button type="button" class="btn btn-default btn-xs" title="Remove">\u2715</button>');
        $removeBtn.on('click', function () {
            removeSortRule(index);
        });
        $row.append($removeBtn);

        $list.append($row);
    });
}

function toggleAdvancedPanel() {
    $('#advancedPanel').toggle();
}
