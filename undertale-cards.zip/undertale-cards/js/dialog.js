var dialogs = [];
var displayingDialog = false;
var dialogController = null;
var runningDialog = false;
var isSkippingDialog = false;

var tickPool = [];
var tickPoolIndex = 0;
var tickPoolSoundName = null;
var tickPoolVolume = 0.3;
var tickPoolSize = 8;

function isDialogSoundEnabled() {
    if (typeof soundEnabled === 'boolean') {
        return soundEnabled;
    }

    return localStorage.getItem("gameSoundsDisabled") === null;
}

function stopTickPool() {
    if (!tickPool || !tickPool.length) return;
    for (const a of tickPool) {
        try {
            a.pause();
            a.currentTime = 0;
        } catch (_) {
        }
    }
}

function initTickPool(soundName, volume = 0.3, poolSize = 8) {
    const vol = Math.max(0, Math.min(1, Number(volume) || 0));
    const size = Math.max(1, poolSize | 0);

    stopTickPool();

    tickPool = [];
    tickPoolIndex = 0;
    tickPoolSoundName = soundName;
    tickPoolVolume = vol;
    tickPoolSize = size;

    /*
     * UCAudio handles overlapping dialog ticks through Web Audio. The HTMLAudio
     * pool is kept only as a fallback when audio.js has not been loaded.
     */
    if (window.UCAudio !== undefined
        && typeof window.UCAudio.playSound === 'function') {
        if (typeof window.UCAudio.preloadSound === 'function') {
            window.UCAudio.preloadSound(soundName);
        }

        return;
    }

    for (let i = 0; i < size; i++) {
        const a = new Audio('/sounds/' + soundName + '.wav');
        a.preload = "auto";
        a.volume = vol;
        tickPool.push(a);
    }
}

function playTickFromPool() {
    if (!tickPool.length) return;

    const a = tickPool[tickPoolIndex];
    tickPoolIndex = (tickPoolIndex + 1) % tickPool.length;

    try {
        a.currentTime = 0;
        const p = a.play();

        if (p && typeof p.catch === "function") {
            p.catch(() => {
                // The fallback tick may be blocked before the first interaction.
            });
        }
    } catch (_) {
        // The fallback is intentionally best effort.
    }
}

function playDialogTick() {
    if (!tickPoolSoundName) return;

    if (window.UCAudio !== undefined
        && typeof window.UCAudio.playSound === 'function') {
        window.UCAudio.playSound(tickPoolSoundName, tickPoolVolume);
        return;
    }

    playTickFromPool();
}


function refreshDialogListener() {
    $(document)
        .off("click.dialog", ".next-event")
        .on("click.dialog", ".next-event", () => {
            if (isDialogOpen()) {
                if (runningDialog) skipDialog();
                else nextDialog();
            }
        });
}


// --- Utilitaire principal: typeHtml ---
// Nouveaux paramètres : tickSoundName (string) et tickSoundVolume (0..1)
function typeHtml({sourceHtml, stepMs = 16, onDone, tickSoundName = null, tickSoundVolume = 1} = {}) {

    var target = document.querySelector(".ut-text p");
    if (!target) throw new Error("target manquant");

    // 1) Parser le HTML source en mémoire
    const tpl = document.createElement("template");
    tpl.innerHTML = sourceHtml.trim();
    const srcFrag = tpl.content;

    if (tickSoundName) {
        initTickPool(tickSoundName, tickSoundVolume, 8);
    } else {
        stopTickPool();
        tickPool = [];
        tickPoolIndex = 0;
        tickPoolSoundName = null;
        tickPoolVolume = 0.3;
    }

    const playTick = () => {
        if (!isDialogSoundEnabled()) return;
        if (isSkippingDialog) return;
        playDialogTick();
    };

    // 2) Construire la liste des étapes
    const steps = [];

    function scheduleAppend(node, parentOut) {
        steps.push(() => parentOut.appendChild(node));
    }

    function buildSteps(srcNode, outParent) {
        if (srcNode.nodeType === Node.ELEMENT_NODE) {
            const el = /** @type {HTMLElement} */ (srcNode.cloneNode(false));
            scheduleAppend(el, outParent);
            for (const child of srcNode.childNodes) buildSteps(child, el);
        } else if (srcNode.nodeType === Node.TEXT_NODE) {

            const text = srcNode.nodeValue || "";
            const words = text.split(/(\s+)/); // garde les espaces
            let outText = document.createTextNode("");
            scheduleAppend(outText, outParent);

            for (const token of words) {

                // Gestion caractère spécial ^ = nouvelle ligne + "* "
                if (token.includes("^")) {
                    for (const ch of token) {
                        if (ch === "^") {
                            steps.push(() => {
                                outText.nodeValue += "\n*";
                            });
                        } else {
                            steps.push(() => {
                                outText.nodeValue += ch;
                                if (!/\s/.test(ch)) playTick();
                            });
                        }
                    }
                    continue;
                }

                // Mesure automatique de retour à la ligne (ton code existant)
                if (!/^\s+$/.test(token)) {
                    const testSpan = document.createElement("span");
                    testSpan.style.visibility = "hidden";
                    testSpan.style.position = "absolute";
                    testSpan.style.whiteSpace = "nowrap";
                    testSpan.textContent = token;

                    outParent.appendChild(testSpan);
                    const parentWidth = outParent.clientWidth;
                    const spanWidth = testSpan.offsetWidth;
                    outParent.removeChild(testSpan);

                    if (spanWidth > parentWidth) {
                        steps.push(() => {
                            outText.nodeValue += "\n";
                        });
                    }
                }

                // Écriture char par char
                for (const ch of token) {
                    steps.push(() => {
                        outText.nodeValue += ch;
                        if (!/\s/.test(ch)) playTick();
                    });
                }
            }
        } else if (srcNode.nodeType === Node.COMMENT_NODE) {
            // ignorer
        } else {
            const clone = srcNode.cloneNode(true);
            scheduleAppend(clone, outParent);
        }
    }

    for (const child of srcFrag.childNodes) buildSteps(child, target);

    // 3) Jouer les étapes avec un intervalle
    let i = 0;
    let timer = null;

    function tick() {
        steps[i++]?.();
        if (i >= steps.length) {
            stop();
            target.classList.remove("typing-caret");
            onDone?.();
        }
    }

    function play() {
        if (!timer) timer = setInterval(tick, stepMs);
    }

    function pause() {
        if (timer) {
            clearInterval(timer);
            timer = null;
        }
    }

    function stop() {
        if (timer) {
            clearInterval(timer);
            timer = null;
        }
    }

    function skipToEnd() {
        pause();
        while (i < steps.length) steps[i++]();
        onDone?.();
    }

    return {
        play, pause, skipToEnd,
        setSpeed(ms) {
            const was = !!timer;
            pause();
            stepMs = Math.max(1, +ms || 1);
            if (was) play();
        }
    };
}

function displayDialogBox(translationId, avatarImage, sound) {

    removeDialogBox();

    var $box = '<div class="ut-box next-event">';

    if (avatarImage !== undefined) {
        $box += '<div class="ut-avatar"><img src="/images/portraits/' + avatarImage + '.png" alt="Avatar"/></div>';
    }

    $box += '<div class="ut-text"><p></p></div></div>';

    var $htmlText = '* ' + $.i18n(translationId);

    $('body').append($box);

    refreshDialogListener();

    var params = {
        sourceHtml: $htmlText,
        stepMs: 48,
        onDone() {
            runningDialog = false;
            const path = '/images/portraits/' + avatarImage + 'Static.png'
            $('.ut-avatar img').prop('src', path);
        }
    };

    if (sound !== undefined) {
        params.tickSoundName = sound;
    }

    dialogController = typeHtml(params);
    dialogController.play();
    runningDialog = true;

    checkTutorial(translationId);

    if (mobile) {
        skipDialog();
    }
}

function removeDialogBox() {
    // Stop net tous les ticks quand la box disparaît
    stopTickPool();

    $('.ut-box').remove();
    displayingDialog = false;
    dialogController = null;
}

function skipDialog() {
    if (dialogController !== null) {
        isSkippingDialog = true;
        stopTickPool();
        dialogController.skipToEnd();
        isSkippingDialog = false;

        if (isDialogSoundEnabled()) {
            playDialogTick();
        }
    }
}

function isDialogOpen() {
    return dialogController !== null;
}

function clearDialogs() {
    removeDialogBox();
    dialogs = [];
}

function nextDialog() {

    // Quand on change de dialogue, stop net les ticks en cours
    stopTickPool();
    isSkippingDialog = false;

    if (dialogs.length > 0) {
        lockOverlay();
        var dialog = dialogs.shift();
        displayDialogBox(dialog.translationId, dialog.avatar, dialog.sound);
        displayingDialog = true;
    } else {
        removeDialogBox();
        unlockOverlay();
        clearHighlight();
        displayingDialog = false;

        if (typeof nextEvent === "function") {
            nextEvent();
        }
    }

    $('#hover-card').remove();
}

function checkTutorial(translationId) {

    if (translationId === 'story-dialog-flowey-1') {
        $('#endTurnBtn').hide();
    }

    if (translationId === 'story-dialog-flowey-7') {
        highlight('.card');
        disableDraggable();
    }

    if (translationId === 'story-dialog-flowey-8') {
        highlight('#yourSide');
        $('.ut-box').css('top', '122px');
        makeDraggable();
    }

    if (translationId === 'story-dialog-flowey-9') {
        $('.ut-box').css('top', '122px');
        clearHighlight();
        highlight('#board .card .cardHP');
        highlight('#board .card .cardATK');
    }

    if (translationId === 'story-dialog-flowey-10') {
        $('.ut-box').css('top', '122px');
    }

    if (translationId === 'story-dialog-flowey-11') {
        $('.ut-box').css('top', '122px');
        clearHighlight();
        highlight('#board .cardCost');
    }

    if (translationId === 'story-dialog-flowey-12') {
        $('.ut-box').css('top', '122px');
        clearHighlight();
        highlight('#yourGold');
    }

    if (translationId === 'story-dialog-flowey-13') {
        $('.ut-box').css('top', '122px');
        clearHighlight();
        $('#endTurnBtn').show();
        highlight('#endTurnBtn');
    }

    if (translationId === 'story-dialog-flowey-14') {
        clearHighlight();
        highlight('#yourDeck');
        $('#endTurnBtn').hide();
    }

    if (translationId === 'story-dialog-flowey-15') {
        clearHighlight();
    }

    if (translationId === 'story-dialog-flowey-16') {
        $('.ut-box').css('top', '600px');
    }

    if (translationId === 'story-dialog-flowey-17') {
        clearHighlight();
        highlight('.cardHP.damaged');
    }

    if (translationId === 'story-dialog-flowey-17' || translationId === 'story-dialog-flowey-19') {
        $('.ut-box').css('top', '600px');
    }

    if (translationId === 'story-dialog-flowey-19') {
        clearHighlight();
    }

    if (translationId === 'story-dialog-flowey-18' || translationId === 'story-dialog-flowey-20') {
        $('#endTurnBtn').show();
        highlight('#endTurnBtn');
    }

    if (translationId === 'story-dialog-flowey-21') {
        clearHighlight();
        highlight('#yourHp');
    }

    if (translationId === 'story-dialog-flowey-22') {
        if (music) {
            music.pause();
        }
    }

    if (translationId === 'story-dialog-flowey-23') {
        playSound('floweyLaugh');
    }

    //Dummy fight
    if (translationId === 'story-dialog-toriel-3') {
        updateZone(1);
    }

    if (translationId === 'story-dialog-toriel-4') {
        highlight('#fight-2');
    }

    if (translationId === 'story-dialog-toriel-10') {
        highlight('#10001');
    }

    if (translationId === 'story-dialog-toriel-11') {
        $('.ut-box').css('top', '600px');
        highlight('#enemySide .monster');
    }

    if (translationId === 'story-dialog-toriel-11-1') {
        $('.ut-box').css('top', '600px');
        highlight('#enemyHp');
    }

    if (translationId === 'story-dialog-toriel-12') {
        highlight('#10005');
    }

    if (translationId === 'story-dialog-toriel-14' && idFight === 2) {
        playSound('phone');
    }

    //Froggit Fight
    if (translationId === 'story-dialog-froggit-2') {
        highlight('.MONSTER')
    }

    if (translationId === 'story-dialog-froggit-3') {
        clearHighlight();
        highlight('.KINDNESS')
    }

    if (translationId === 'story-dialog-froggit-5') {
        highlight('.artifact-img')
    }

    if (translationId === 'story-dialog-napstablook-6') {
        highlight('#10001')
    }

    if (translationId === 'story-dialog-napstablook-11') {
        if (music) {
            music.pause();
        }
    }

    if (translationId === 'story-dialog-toriel-20' || translationId === 'story-dialog-toriel-26') {
        if (music) {
            music.pause();
        }

        if (jingle) {
            jingle.pause();
        }
    }

    if (translationId === 'tutorial-dialog-decks-1') {
        $('.ut-box').css('top', '65px');
        highlight('.card');
    }

    if (translationId === 'tutorial-dialog-decks-2' || translationId === 'tutorial-dialog-decks-3') {
        $('.ut-box').css('top', '65px');
    }

    if (translationId === 'tutorial-dialog-decks-4') {
        clearHighlight();
        $('.ut-box').css('top', '65px');
        highlight('#deckCardsCanvas');
    }

    if (translationId === 'tutorial-dialog-decks-5') {
        clearHighlight();
        highlight('#artifactSlot1');
        highlight('#artifactSlot2');
    }

    if (translationId === 'tutorial-dialog-decks-6') {
        clearHighlight();
        highlight('#artifactClear');
    }

    if (translationId === 'tutorial-dialog-decks-7') {
        clearHighlight();
        $('.ut-box').css('top', '280px');
        highlight('#soulInfo');
    }

    if (translationId === 'tutorial-dialog-decks-8') {
        clearHighlight();
        $('.ut-box').css('top', '280px');
        highlight('#selectSouls');
    }

    if (translationId === 'tutorial-dialog-decks-9') {
        clearHighlight();
    }

    if (translationId === 'tutorial-dialog-craft-2') {
        highlight('#dust-group');
    }

    if (translationId === 'tutorial-dialog-craft-3') {
        clearHighlight();
        $('#commonRarityInput').prop( "checked", true );
        applyFilters();
        showPage(0);
        $('.ut-box').css('top', '65px');
        highlight('#collection');
    }

    if (translationId === 'tutorial-dialog-craft-4') {
        $('.ut-box').css('top', '65px');
    }

    if (translationId === 'tutorial-dialog-craft-5') {
        $('.ut-box').css('top', '65px');
    }

    if (translationId === 'tutorial-dialog-craft-6') {
        $('#commonRarityInput').prop( "checked", false );
        $('#determinationRarityInput').prop( "checked", true);
        $('.ut-box').css('top', '225px');
        applyFilters();
        showPage(0);
        highlight('#DTFragmentsDiv');
    }

    if (translationId === 'tutorial-dialog-craft-7') {
        clearHighlight();
        $('#determinationRarityInput').prop( "checked", false);
        $('.ut-box').css('top', '225px');
        applyFilters();
        showPage(0);
        highlight('.btn-info');
    }

    if (translationId === 'tutorial-dialog-craft-8') {
        clearHighlight();
        $('.ut-box').css('top', '65px');
        highlight('#collection');
    }

    if (translationId === 'tutorial-dialog-craft-9') {
        clearHighlight();
        $('.ut-box').css('top', '320px');
        highlight('#filter-group');
    }

    if (translationId === 'story-dialog-dogamydogaressa-3') {
        highlight('#10003');
    }

    if (translationId === 'story-dialog-dogamydogaressa-6') {
        clearHighlight();
    }

    if (translationId.startsWith('story-dialog-papyrus-')) {
        $('.ut-box p').css('font-family', '"Papyrus", serif');
    }

    if (translationId === 'story-dialog-papyrus-7') {
        if (music) {
            music.pause();
            playBackgroundMusic('Bonetrousle');
        }
    }

    if (translationId === 'story-dialog-papyrus-9') {
        $('.ut-box').css('top', '120px');
        highlight('.enchant-info');
    }

    if (translationId === 'story-dialog-papyrus-10') {
        clearHighlight();
    }

    if (translationId === 'story-dialog-papyrus-27') {
        if (music) {
            music.pause();
        }
    }
}

function highlight(element) {
    $(element).addClass('highlight');
}

function clearHighlight() {
    $('.highlight').removeClass('highlight');
}

function lockOverlay() {
    if ($('#lock-overlay').length === 0) {
        $('body').append('<div id="lock-overlay" class="next-event"></div>');
    }
}

function unlockOverlay() {
    $('#lock-overlay').remove();
}

