/* global mobile, humanize, language, colorDesc, allCards, translationReady */

var currentPage = 0;
var collection = [];
var pages = [];

function tryInitCollection() {
    if (allCards.length > 0 && translationReady) {
        initCollection();
    }
}

if (!(allCards.length > 0)) {
    document.addEventListener('allCardsReady', tryInitCollection);
}

if (!translationReady) {
    document.addEventListener('translationReady', tryInitCollection);
}

tryInitCollection();

function initCollection() {
    collection = cloneList(allCards);
    applyFilters();
    showPage(0);
}

$(document).ready(function () {

    document.getElementById('collection').addEventListener('wheel', function (e) {

        e.preventDefault();
        e.stopPropagation();

        if (e.deltaY > 0) {
            nextPage();
        } else if (e.deltaY < 0) {
            previousPage();
        }
    });

    $('#searchInput').keyup(function () {
        applyFilters();
        showPage(0);
    });

});

function applyFilters() {

    pages = [];

    var filteredCollection = cloneList(collection);

    //Filters

    for (var i = filteredCollection.length - 1; i >= 0; i--) {

        var card = filteredCollection[i];

        if (isRemoved(card)) {
            filteredCollection.splice(i, 1);
        }
    }

    for (var i = 0; i < filteredCollection.length; i++) {
        pages.push(filteredCollection[i]);
    }

    $('#maxPage').html(getMaxPage() + 1);

}


function nextPage() {

    if (currentPage < getMaxPage()) {
        currentPage++;

        showPage(currentPage);
        $('#currentPage').html(currentPage + 1);
    }
}

function previousPage() {

    if (currentPage > 0) {
        currentPage--;

        showPage(currentPage);
        $('#currentPage').html(currentPage + 1);
    }

}

function showPage(page) {

    currentPage = page;

    $('#collection').empty();

    var currPage = page * 10;

    for (var i = currPage; i < currPage + 10; i++) {

        if (pages.length > i) {
            var card = pages[i];
            appendCardCraft(card);
        }
    }

    $('#currentPage').html(currentPage + 1);

    $('#btnNext').prop('disabled', page >= getMaxPage());
    $('#btnPrevious').prop('disabled', page === 0);

}

function existPage(page) {
    return page >= 0 && page <= getMaxPage();
}

function getMaxPage() {
    return Math.floor((pages.length - 1) / 10);
}

function isRemoved(card) {

    var removed = false;

    //Shiny
    removed = card.shiny !== $('#shinyInput').prop('checked');

    //Rarity
    if (!removed) {

        var rarities = [];

        $(".rarityInput").each(function (index) {
            if ($(this).prop('checked')) {
                rarities.push($(this).attr('rarity'));
            }
        });

        if (rarities.length > 0) {
            removed = !rarities.includes(card.rarity);
        }

    }

    //Type
    if (!removed) {

        var monster = $('#monsterInput').prop('checked');
        var spell = $('#spellInput').prop('checked');

        if (monster && !spell) {
            removed = card.typeCard !== 0;
        } else if (!monster && spell) {
            removed = card.typeCard !== 1;
        }

    }

    //Extension
    if (!removed) {

        var undertale = $('#undertaleInput').prop('checked');
        var deltarune = $('#deltaruneInput').prop('checked');
        var uty = $('#utyInput').prop('checked');
        var checkedExtensions = [];

        if (undertale) {
            checkedExtensions.push("BASE");
        }

        if (deltarune) {
            checkedExtensions.push("DELTARUNE");
        }

        if (uty) {
            checkedExtensions.push("UTY")
        }

        if (checkedExtensions.length > 0) {
            removed = checkedExtensions.indexOf(card.extension) === -1;
        }
    }

    //Search

    if (!removed) {
        var searchValue = $('#searchInput').val().toLowerCase();

        if (searchValue.length > 0) {
            var findableString = "";

            findableString += $.i18n('card-name-' + card.id, 1);
            findableString += $.i18n('card-' + card.id);

            for (var i = 0; i < card.tribes.length; i++) {
                var tribe = card.tribes[i];
                findableString += $.i18n('tribe-' + tribe.toLowerCase().replace(/_/g, '-'));
            }

            if (card.hasOwnProperty('soul')) {
                findableString += $.i18n('soul-' + card.soul.name.toLowerCase().replace(/_/g, '-'));
            }

            var imageNames = getImagesAlts(findableString);
            var finalString = findableString.toLowerCase().replace(/(<.*?>)/g, '');
            finalString += ' ' + imageNames.join(' ');
            removed = !finalString.toLowerCase().includes(searchValue);
        }
    }

    return removed;
}
